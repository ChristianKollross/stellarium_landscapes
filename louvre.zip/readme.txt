
Louvre, Paris, France
---------------------

Based on four photos taken with an Insta360 One X2.
Photos stacked in Gimp and made partially transparent to remove close by pedestrians.

Image split at:         287.6 degrees
Rotation calculated as: 270 + 287.6 = 197.6
